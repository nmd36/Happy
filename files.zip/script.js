document.addEventListener('DOMContentLoaded', function () {
    const calculatorScreen = document.getElementById('calculator-screen');
    const keys = document.querySelector('.calculator-keys');
    let currentInput = '';
    let operator = '';
    let previousInput = '';

    keys.addEventListener('click', function (event) {
        const { target } = event;
        const { value } = target;

        if (!target.matches('button')) {
            return;
        }

        switch (value) {
            case '+':
            case '-':
            case '*':
            case '/':
                operator = value;
                previousInput = currentInput;
                currentInput = '';
                break;
            case '=':
                if (operator && previousInput !== '' && currentInput !== '') {
                    currentInput = eval(`${previousInput} ${operator} ${currentInput}`);
                    operator = '';
                }
                break;
            case 'all-clear':
                currentInput = '';
                operator = '';
                previousInput = '';
                break;
            case '.':
                if (!currentInput.includes('.')) {
                    currentInput += value;
                }
                break;
            default:
                currentInput += value;
                break;
        }

        calculatorScreen.value = currentInput;
    });
});
``` ▋